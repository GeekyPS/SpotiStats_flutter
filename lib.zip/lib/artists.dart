import 'package:flutter/material.dart';

class Artist extends StatelessWidget {
  final String rank;
  final String name;
  final String imageUrl;

  Artist(this.rank, this.name, this.imageUrl);

  @override
  Widget build(BuildContext context) {
    // ignore: dead_code
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 5),
      height: 80,


  
        child: Column(
          
          children: [
          
            Container(
              child: ClipRRect(
                
                borderRadius: BorderRadius.circular(5),
                child: Image.asset(
                  imageUrl,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            FittedBox(
              child: RichText(
                text: TextSpan(
                    text: '#${rank}',
                    style: TextStyle(
                        color: Colors.grey[600], fontWeight: FontWeight.bold),
                    children: <TextSpan>[
                      TextSpan(
                        text: ' ${name}',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ]),
              ),
            )
          ]),
      );
      
  }
}
